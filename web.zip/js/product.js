console.log("Product details page loaded.");
